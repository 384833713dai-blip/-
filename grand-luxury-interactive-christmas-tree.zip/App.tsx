
import React, { useState } from 'react';
import Scene from './components/Scene';
import { TreeState } from './types';
import { COLORS } from './constants';

const App: React.FC = () => {
  const [treeState, setTreeState] = useState<TreeState>(TreeState.CHAOS);

  const toggleState = () => {
    setTreeState(prev => prev === TreeState.CHAOS ? TreeState.FORMED : TreeState.CHAOS);
  };

  return (
    <div className="relative w-full h-full bg-[#050505]">
      {/* 3D Scene */}
      <Scene state={treeState} />

      {/* UI Overlay */}
      <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-8 md:p-12">
        {/* Header */}
        <div className="flex flex-col gap-2">
          <h1 className="text-4xl md:text-6xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-[#FFD700] via-[#FFF8DC] to-[#FFD700] uppercase italic">
            Grand Luxury
          </h1>
          <p className="text-emerald-500 font-mono tracking-widest text-sm uppercase opacity-80">
            Interactive Christmas Experience // 2024 Edition
          </p>
        </div>

        {/* Bottom Controls */}
        <div className="flex flex-col md:flex-row items-end md:items-center justify-between gap-6 pointer-events-auto">
          <div className="max-w-xs">
            <p className="text-white/60 text-xs leading-relaxed uppercase tracking-wider mb-4 font-light">
              Witness the convergence of high-fidelity particles and luxury dynamics. A cinematic transformation from chaotic energy to a structured grand symbol of elegance.
            </p>
            <div className="flex items-center gap-4">
              <div className={`w-2 h-2 rounded-full animate-pulse ${treeState === TreeState.FORMED ? 'bg-gold-500 shadow-[0_0_10px_#FFD700]' : 'bg-red-500 shadow-[0_0_10px_red]'}`} />
              <span className="text-white font-mono text-xs uppercase">
                Status: {treeState}
              </span>
            </div>
          </div>

          <button
            onClick={toggleState}
            className="group relative px-10 py-5 bg-gradient-to-b from-[#FFD700] to-[#B8860B] rounded-none overflow-hidden transition-all hover:scale-105 active:scale-95 shadow-[0_20px_50px_rgba(255,215,0,0.3)]"
          >
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
            <span className="relative text-black font-black uppercase tracking-widest text-lg">
              {treeState === TreeState.CHAOS ? 'Assemble The Grandeur' : 'Scatter The Joy'}
            </span>
          </button>
        </div>
      </div>

      {/* Background Ambience Hint */}
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 text-[10px] text-white/20 uppercase tracking-widest pointer-events-none">
        Use Mouse to Orbit & Zoom • Double Tap to Reset View
      </div>

      {/* Decorative Borders */}
      <div className="fixed inset-0 border-[20px] border-[#013220]/20 pointer-events-none" />
      <div className="fixed inset-0 border-[1px] border-[#FFD700]/10 pointer-events-none m-4" />
    </div>
  );
};

export default App;
