
import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TREE_CONFIG, COLORS } from '../constants';
import { TreeState } from '../types';

interface FoliageProps {
  state: TreeState;
}

const Foliage: React.FC<FoliageProps> = ({ state }) => {
  const pointsRef = useRef<THREE.Points>(null!);
  const progressRef = useRef(0);

  const { positions, chaosPositions, colors, rustleSeeds } = useMemo(() => {
    const pos = new Float32Array(TREE_CONFIG.PARTICLE_COUNT * 3);
    const cPos = new Float32Array(TREE_CONFIG.PARTICLE_COUNT * 3);
    const col = new Float32Array(TREE_CONFIG.PARTICLE_COUNT * 3);
    const seeds = new Float32Array(TREE_CONFIG.PARTICLE_COUNT);
    
    const emerald = new THREE.Color(COLORS.EMERALD);
    const gold = new THREE.Color(COLORS.GOLD);

    for (let i = 0; i < TREE_CONFIG.PARTICLE_COUNT; i++) {
      // Target Tree Position (Cone)
      const h = Math.random() * TREE_CONFIG.HEIGHT;
      const r = (1 - h / TREE_CONFIG.HEIGHT) * TREE_CONFIG.RADIUS;
      const theta = Math.random() * Math.PI * 2;
      
      pos[i * 3] = Math.cos(theta) * r * Math.pow(Math.random(), 0.5);
      pos[i * 3 + 1] = h - TREE_CONFIG.HEIGHT / 2;
      pos[i * 3 + 2] = Math.sin(theta) * r * Math.pow(Math.random(), 0.5);

      // Chaos Position (Sphere)
      const phi = Math.random() * Math.PI * 2;
      const cosTheta = Math.random() * 2 - 1;
      const u = Math.random();
      const radius = TREE_CONFIG.CHAOS_RADIUS * Math.pow(u, 1/3);
      const sinTheta = Math.sqrt(1 - cosTheta * cosTheta);

      cPos[i * 3] = radius * sinTheta * Math.cos(phi);
      cPos[i * 3 + 1] = radius * cosTheta;
      cPos[i * 3 + 2] = radius * sinTheta * Math.sin(phi);

      // Color variation
      const mixFactor = Math.random();
      const c = emerald.clone().lerp(gold, mixFactor * 0.15);
      col[i * 3] = c.r;
      col[i * 3 + 1] = c.g;
      col[i * 3 + 2] = c.b;

      // Rustle seed for unique movement per particle
      seeds[i] = Math.random();
    }
    return { positions: pos, chaosPositions: cPos, colors: col, rustleSeeds: seeds };
  }, []);

  useFrame((stateObj, delta) => {
    const target = state === TreeState.FORMED ? 1 : 0;
    progressRef.current = THREE.MathUtils.lerp(progressRef.current, target, delta * 2.5);
    
    const attrPos = pointsRef.current.geometry.attributes.position;
    const time = stateObj.clock.getElapsedTime();
    
    // Rustle intensity scales up as the tree forms
    const rustleIntensity = THREE.MathUtils.smoothstep(progressRef.current, 0.8, 1.0) * 0.015;

    for (let i = 0; i < TREE_CONFIG.PARTICLE_COUNT; i++) {
      const idx = i * 3;
      // Interpolate between Chaos and Target
      const baseX = THREE.MathUtils.lerp(chaosPositions[idx], positions[idx], progressRef.current);
      const baseY = THREE.MathUtils.lerp(chaosPositions[idx + 1], positions[idx + 1], progressRef.current);
      const baseZ = THREE.MathUtils.lerp(chaosPositions[idx + 2], positions[idx + 2], progressRef.current);
      
      // Gentle randomized rustle animation
      // We use the unique seed to vary frequency and phase
      const seed = rustleSeeds[i];
      const freq = 1.0 + seed * 2.0;
      const phase = seed * Math.PI * 2;
      
      const offsetX = Math.sin(time * freq + phase) * rustleIntensity;
      const offsetY = Math.cos(time * (freq * 0.8) + phase) * (rustleIntensity * 0.5);
      const offsetZ = Math.sin(time * (freq * 1.2) + phase * 0.5) * rustleIntensity;

      attrPos.array[idx] = baseX + offsetX;
      attrPos.array[idx + 1] = baseY + offsetY;
      attrPos.array[idx + 2] = baseZ + offsetZ;
    }
    attrPos.needsUpdate = true;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={TREE_CONFIG.PARTICLE_COUNT}
          array={chaosPositions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={TREE_CONFIG.PARTICLE_COUNT}
          array={colors}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.06}
        vertexColors
        transparent
        opacity={0.8}
        blending={THREE.AdditiveBlending}
        sizeAttenuation
      />
    </points>
  );
};

export default Foliage;
