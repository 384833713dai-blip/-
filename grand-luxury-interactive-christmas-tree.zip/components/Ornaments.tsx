
import React, { useMemo, useRef, useState } from 'react';
import { useFrame, ThreeEvent } from '@react-three/fiber';
import * as THREE from 'three';
import { TREE_CONFIG, COLORS } from '../constants';
import { TreeState, OrnamentData } from '../types';

interface OrnamentsProps {
  state: TreeState;
}

interface ActiveAnimation {
  startTime: number;
  instanceId: number;
  type: string;
}

const Ornaments: React.FC<OrnamentsProps> = ({ state }) => {
  const ballRef = useRef<THREE.InstancedMesh>(null!);
  const boxRef = useRef<THREE.InstancedMesh>(null!);
  const lightRef = useRef<THREE.InstancedMesh>(null!);
  
  const progressRef = useRef(0);
  // Store active pulse animations: key is "type-id", value is start time
  const activeAnimations = useRef<Map<string, number>>(new Map());

  const ornaments = useMemo(() => {
    const data: OrnamentData[] = [];
    const colors = [COLORS.GOLD, COLORS.GOLD_BRIGHT, COLORS.LUXURY_RED, '#FFFFFF'];

    for (let i = 0; i < TREE_CONFIG.ORNAMENT_COUNT; i++) {
      const h = Math.random() * TREE_CONFIG.HEIGHT;
      const r = (1 - h / TREE_CONFIG.HEIGHT) * TREE_CONFIG.RADIUS * 0.95;
      const theta = Math.random() * Math.PI * 2;

      const typeRoll = Math.random();
      let type: 'ball' | 'box' | 'light' = 'ball';
      let weight = 1.0;
      if (typeRoll > 0.7) { type = 'box'; weight = 2.0; }
      else if (typeRoll < 0.2) { type = 'light'; weight = 0.3; }

      data.push({
        targetPos: [
          Math.cos(theta) * r,
          h - TREE_CONFIG.HEIGHT / 2,
          Math.sin(theta) * r
        ],
        chaosPos: [
          (Math.random() - 0.5) * TREE_CONFIG.CHAOS_RADIUS * 2,
          (Math.random() - 0.5) * TREE_CONFIG.CHAOS_RADIUS * 2,
          (Math.random() - 0.5) * TREE_CONFIG.CHAOS_RADIUS * 2,
        ],
        type,
        color: colors[Math.floor(Math.random() * colors.length)],
        scale: Math.random() * 0.4 + 0.1,
        weight,
      });
    }
    return data;
  }, []);

  const ballData = ornaments.filter(o => o.type === 'ball');
  const boxData = ornaments.filter(o => o.type === 'box');
  const lightData = ornaments.filter(o => o.type === 'light');

  const dummy = new THREE.Object3D();

  const handlePointerDown = (e: ThreeEvent<PointerEvent>, type: string) => {
    e.stopPropagation();
    if (e.instanceId !== undefined) {
      const key = `${type}-${e.instanceId}`;
      activeAnimations.current.set(key, performance.now() / 1000);
    }
  };

  useFrame((stateObj, delta) => {
    const currentTime = stateObj.clock.elapsedTime;
    const target = state === TreeState.FORMED ? 1 : 0;
    progressRef.current = THREE.MathUtils.lerp(progressRef.current, target, delta * 2.0);

    const updateMesh = (mesh: THREE.InstancedMesh, dataset: OrnamentData[], type: string) => {
      dataset.forEach((data, i) => {
        const individualProgress = THREE.MathUtils.clamp(progressRef.current * (1 / data.weight) + (Math.sin(i) * 0.05), 0, 1);
        
        let x = THREE.MathUtils.lerp(data.chaosPos[0], data.targetPos[0], individualProgress);
        let y = THREE.MathUtils.lerp(data.chaosPos[1], data.targetPos[1], individualProgress);
        let z = THREE.MathUtils.lerp(data.chaosPos[2], data.targetPos[2], individualProgress);
        
        // Organic bobbing/swaying motion when formed
        if (individualProgress > 0.9) {
          const swayAlpha = THREE.MathUtils.smoothstep(individualProgress, 0.9, 1.0);
          const t = currentTime + i * 0.5;
          // Very subtle horizontal and vertical offsets
          x += Math.sin(t * 0.4) * 0.03 * swayAlpha;
          y += Math.cos(t * 0.5) * 0.02 * swayAlpha;
          z += Math.sin(t * 0.3) * 0.03 * swayAlpha;
        }

        dummy.position.set(x, y, z);
        
        if (progressRef.current < 0.95) {
          dummy.rotation.set(
            currentTime * 0.5 * data.weight + i,
            currentTime * 0.3 + i,
            0
          );
        } else {
          // Subtle wobble rotation when formed
          const wobbleAlpha = THREE.MathUtils.smoothstep(progressRef.current, 0.95, 1.0);
          dummy.rotation.set(
            Math.sin(currentTime * 0.6 + i) * 0.04 * wobbleAlpha,
            Math.cos(currentTime * 0.4 + i) * 0.04 * wobbleAlpha,
            0
          );
        }

        // Interaction Feedback: Scale Pulse
        const animKey = `${type}-${i}`;
        const startTime = activeAnimations.current.get(animKey);
        let pulseScale = 1;
        
        if (startTime !== undefined) {
          const elapsed = currentTime - startTime;
          const duration = 0.6; // duration of pulse in seconds
          if (elapsed < duration) {
            // Sine wave pulse: starts at 1, peaks at 2.5, returns to 1
            pulseScale = 1 + Math.sin((elapsed / duration) * Math.PI) * 1.5;
          } else {
            activeAnimations.current.delete(animKey);
          }
        }

        dummy.scale.setScalar(data.scale * pulseScale);
        dummy.updateMatrix();
        mesh.setMatrixAt(i, dummy.matrix);
      });
      mesh.instanceMatrix.needsUpdate = true;
    };

    if (ballRef.current) updateMesh(ballRef.current, ballData, 'ball');
    if (boxRef.current) updateMesh(boxRef.current, boxData, 'box');
    if (lightRef.current) updateMesh(lightRef.current, lightData, 'light');
  });

  return (
    <>
      <instancedMesh 
        ref={ballRef} 
        args={[undefined, undefined, ballData.length]} 
        onPointerDown={(e) => handlePointerDown(e, 'ball')}
        onPointerOver={() => (document.body.style.cursor = 'pointer')}
        onPointerOut={() => (document.body.style.cursor = 'auto')}
      >
        <sphereGeometry args={[0.3, 16, 16]} />
        <meshStandardMaterial metalness={0.9} roughness={0.1} color={COLORS.GOLD} />
      </instancedMesh>

      <instancedMesh 
        ref={boxRef} 
        args={[undefined, undefined, boxData.length]} 
        onPointerDown={(e) => handlePointerDown(e, 'box')}
        onPointerOver={() => (document.body.style.cursor = 'pointer')}
        onPointerOut={() => (document.body.style.cursor = 'auto')}
      >
        <boxGeometry args={[0.4, 0.4, 0.4]} />
        <meshStandardMaterial metalness={0.8} roughness={0.2} color={COLORS.LUXURY_RED} />
      </instancedMesh>

      <instancedMesh 
        ref={lightRef} 
        args={[undefined, undefined, lightData.length]} 
        onPointerDown={(e) => handlePointerDown(e, 'light')}
        onPointerOver={() => (document.body.style.cursor = 'pointer')}
        onPointerOut={() => (document.body.style.cursor = 'auto')}
      >
        <sphereGeometry args={[0.1, 8, 8]} />
        <meshStandardMaterial emissive={COLORS.GOLD_BRIGHT} emissiveIntensity={5} color={COLORS.GOLD_BRIGHT} />
      </instancedMesh>
    </>
  );
};

export default Ornaments;
