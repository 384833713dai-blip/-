
import React from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment, ContactShadows } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette } from '@react-three/postprocessing';
import Foliage from './Foliage';
import Ornaments from './Ornaments';
import Star from './Star';
import Snowflakes from './Snowflakes';
import TextParticles from './TextParticles';
import { TreeState } from '../types';
import { COLORS } from '../constants';

interface SceneProps {
  state: TreeState;
}

const Scene: React.FC<SceneProps> = ({ state }) => {
  return (
    <Canvas shadows gl={{ antialias: false, alpha: false }}>
      <color attach="background" args={[COLORS.BACKGROUND]} />
      <PerspectiveCamera makeDefault position={[0, 2, 22]} fov={45} />
      <OrbitControls 
        enablePan={false} 
        minDistance={10} 
        maxDistance={40} 
        autoRotate={state === TreeState.FORMED}
        autoRotateSpeed={0.5}
      />

      <ambientLight intensity={0.2} />
      <spotLight 
        position={[10, 20, 10]} 
        angle={0.15} 
        penumbra={1} 
        intensity={2} 
        castShadow 
        color={COLORS.GOLD_BRIGHT}
      />
      <pointLight position={[-10, -10, -10]} intensity={1} color={COLORS.EMERALD} />

      <Foliage state={state} />
      <Ornaments state={state} />
      <Star state={state} />
      <Snowflakes state={state} />
      <TextParticles state={state} />

      <ContactShadows 
        opacity={0.4} 
        scale={20} 
        blur={2} 
        far={10} 
        resolution={256} 
        color={COLORS.EMERALD} 
      />

      <Environment preset="night" />

      <EffectComposer disableNormalPass>
        <Bloom 
          luminanceThreshold={0.8} 
          mipmapBlur 
          intensity={1.5} 
          radius={0.4}
        />
        <Vignette eskil={false} offset={0.1} darkness={1.1} />
      </EffectComposer>
    </Canvas>
  );
};

export default Scene;
