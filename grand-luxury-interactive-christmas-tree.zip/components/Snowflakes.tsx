
import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { SNOW_CONFIG, COLORS } from '../constants';
import { TreeState } from '../types';

interface SnowflakesProps {
  state: TreeState;
}

const Snowflakes: React.FC<SnowflakesProps> = ({ state }) => {
  const pointsRef = useRef<THREE.Points>(null!);
  const opacityRef = useRef(0);
  
  // Create static buffers for initial positions and per-particle data
  const { positions, velocities } = useMemo(() => {
    const pos = new Float32Array(SNOW_CONFIG.COUNT * 3);
    const vels = new Float32Array(SNOW_CONFIG.COUNT * 3);

    for (let i = 0; i < SNOW_CONFIG.COUNT; i++) {
      // Random position in a box
      pos[i * 3] = (Math.random() - 0.5) * SNOW_CONFIG.VOLUME;
      pos[i * 3 + 1] = (Math.random() - 0.5) * SNOW_CONFIG.VOLUME;
      pos[i * 3 + 2] = (Math.random() - 0.5) * SNOW_CONFIG.VOLUME;

      // Random velocities
      vels[i * 3] = (Math.random() - 0.5) * SNOW_CONFIG.DRIFT_SPEED_BASE; // x drift
      vels[i * 3 + 1] = Math.random() * 0.05 + SNOW_CONFIG.FALL_SPEED_BASE; // y fall speed
      vels[i * 3 + 2] = (Math.random() - 0.5) * SNOW_CONFIG.DRIFT_SPEED_BASE; // z drift
    }
    return { positions: pos, velocities: vels };
  }, []);

  useFrame((stateObj, delta) => {
    const targetOpacity = state === TreeState.FORMED ? 0.6 : 0;
    opacityRef.current = THREE.MathUtils.lerp(opacityRef.current, targetOpacity, delta * 1.5);
    
    // Skip update if invisible
    if (opacityRef.current < 0.01) {
        if (pointsRef.current) pointsRef.current.visible = false;
        return;
    }
    pointsRef.current.visible = true;

    const attrPos = pointsRef.current.geometry.attributes.position;
    const time = stateObj.clock.getElapsedTime();

    for (let i = 0; i < SNOW_CONFIG.COUNT; i++) {
      const idx = i * 3;
      
      // Update Y (falling)
      attrPos.array[idx + 1] -= velocities[idx + 1];
      
      // Update X & Z (drift with sine wave for natural movement)
      attrPos.array[idx] += velocities[idx] + Math.sin(time + i) * 0.005;
      attrPos.array[idx + 2] += velocities[idx + 2] + Math.cos(time + i) * 0.005;

      // Wrap around
      const halfVol = SNOW_CONFIG.VOLUME / 2;
      if (attrPos.array[idx + 1] < -halfVol) {
        attrPos.array[idx + 1] = halfVol;
        attrPos.array[idx] = (Math.random() - 0.5) * SNOW_CONFIG.VOLUME;
        attrPos.array[idx + 2] = (Math.random() - 0.5) * SNOW_CONFIG.VOLUME;
      }
      
      // Boundary check for X/Z to keep them in the volume
      if (Math.abs(attrPos.array[idx]) > halfVol) attrPos.array[idx] *= -0.95;
      if (Math.abs(attrPos.array[idx + 2]) > halfVol) attrPos.array[idx + 2] *= -0.95;
    }
    
    attrPos.needsUpdate = true;
    (pointsRef.current.material as THREE.PointsMaterial).opacity = opacityRef.current;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={SNOW_CONFIG.COUNT}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.08}
        color={COLORS.SNOW}
        transparent
        opacity={0}
        blending={THREE.AdditiveBlending}
        sizeAttenuation
      />
    </points>
  );
};

export default Snowflakes;
