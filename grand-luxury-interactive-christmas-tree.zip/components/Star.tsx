
import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TREE_CONFIG, COLORS } from '../constants';
import { TreeState } from '../types';

interface StarProps {
  state: TreeState;
}

const Star: React.FC<StarProps> = ({ state }) => {
  const meshRef = useRef<THREE.Mesh>(null!);
  const progressRef = useRef(0);

  // Create a 5-pointed star shape
  const starGeometry = useMemo(() => {
    const shape = new THREE.Shape();
    const outerRadius = 0.8;
    const innerRadius = 0.35;
    const points = 5;

    for (let i = 0; i < points * 2; i++) {
      // Swapping the order: Start with innerRadius at i=0 (which corresponds to -PI/2, the bottom)
      const radius = i % 2 === 0 ? innerRadius : outerRadius;
      const angle = (i * Math.PI) / points - Math.PI / 2;
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;

      if (i === 0) {
        shape.moveTo(x, y);
      } else {
        shape.lineTo(x, y);
      }
    }
    shape.closePath();

    const extrudeSettings = {
      steps: 1,
      depth: 0.2,
      bevelEnabled: true,
      bevelThickness: 0.1,
      bevelSize: 0.1,
      bevelOffset: 0,
      bevelSegments: 3,
    };

    const geometry = new THREE.ExtrudeGeometry(shape, extrudeSettings);
    geometry.center(); // Center the geometry for proper rotation
    return geometry;
  }, []);

  useFrame((_, delta) => {
    const target = state === TreeState.FORMED ? 1 : 0;
    progressRef.current = THREE.MathUtils.lerp(progressRef.current, target, delta * 1.5);

    // Adjusted targetY slightly to account for the star sitting in its notch
    const targetY = TREE_CONFIG.HEIGHT / 2 + 0.3; 
    const chaosPos = new THREE.Vector3(0, TREE_CONFIG.CHAOS_RADIUS * 0.8, 0);
    const formedPos = new THREE.Vector3(0, targetY, 0);

    meshRef.current.position.lerpVectors(chaosPos, formedPos, progressRef.current);
    
    // Luxury rotation: slow spin on Y and a slight wobble
    meshRef.current.rotation.y += delta * 0.8;
    meshRef.current.rotation.z = Math.sin(_.clock.elapsedTime) * 0.1;
    
    meshRef.current.scale.setScalar(THREE.MathUtils.lerp(0.1, 1.2, progressRef.current));
  });

  return (
    <mesh ref={meshRef} geometry={starGeometry}>
      <meshStandardMaterial 
        color={COLORS.GOLD} 
        emissive={COLORS.GOLD} 
        emissiveIntensity={6} 
        metalness={1} 
        roughness={0.05} 
      />
      <pointLight intensity={15} distance={12} color={COLORS.GOLD} />
    </mesh>
  );
};

export default Star;
