
import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TEXT_CONFIG, COLORS, TREE_CONFIG } from '../constants';
import { TreeState } from '../types';

interface TextParticlesProps {
  state: TreeState;
}

const TextParticles: React.FC<TextParticlesProps> = ({ state }) => {
  const pointsRef = useRef<THREE.Points>(null!);
  const progressRef = useRef(0);

  // We memoize the base values to avoid recalculation
  const { positions, chaosPositions, baseColors, noiseOffsets } = useMemo(() => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return { positions: new Float32Array(), chaosPositions: new Float32Array(), baseColors: new Float32Array(), noiseOffsets: new Float32Array() };

    canvas.width = 1024;
    canvas.height = 320;
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = 'white';
    
    // Calligraphic Xing Shu font style
    ctx.font = 'italic bold 130px "STKaiti", "Kaiti", "LiSu", "cursive", serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(TEXT_CONFIG.MESSAGE, canvas.width / 2, canvas.height / 2);

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const sampledPoints: [number, number][] = [];
    
    for (let y = 0; y < canvas.height; y += 3) {
      for (let x = 0; x < canvas.width; x += 3) {
        const index = (y * canvas.width + x) * 4;
        if (imageData.data[index] > 100) { 
          sampledPoints.push([
            (x - canvas.width / 2) * TEXT_CONFIG.SCALE,
            (canvas.height / 2 - y) * TEXT_CONFIG.SCALE
          ]);
        }
      }
    }

    const pos = new Float32Array(TEXT_CONFIG.PARTICLE_COUNT * 3);
    const cPos = new Float32Array(TEXT_CONFIG.PARTICLE_COUNT * 3);
    const bCols = new Float32Array(TEXT_CONFIG.PARTICLE_COUNT * 3);
    const noise = new Float32Array(TEXT_CONFIG.PARTICLE_COUNT * 3);

    const gradientColors = [
      new THREE.Color(COLORS.LUXURY_RED),
      new THREE.Color(COLORS.GOLD),
      new THREE.Color('#FFFFFF'), 
      new THREE.Color('#00FF7F'), 
      new THREE.Color('#00BFFF'), 
      new THREE.Color(COLORS.LUXURY_RED)
    ];

    const getGradientColor = (t: number) => {
      const scaledT = t * (gradientColors.length - 1);
      const index = Math.floor(scaledT);
      const weight = scaledT - index;
      if (index >= gradientColors.length - 1) return gradientColors[gradientColors.length - 1];
      return gradientColors[index].clone().lerp(gradientColors[index + 1], weight);
    };

    let minX = Infinity, maxX = -Infinity;
    sampledPoints.forEach(([x]) => {
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
    });
    const width = maxX - minX;

    for (let i = 0; i < TEXT_CONFIG.PARTICLE_COUNT; i++) {
      const point = sampledPoints[i % sampledPoints.length];
      
      pos[i * 3] = point[0];
      pos[i * 3 + 1] = point[1] + TEXT_CONFIG.Y_OFFSET;
      pos[i * 3 + 2] = TEXT_CONFIG.Z_OFFSET;

      const phi = Math.random() * Math.PI * 2;
      const cosTheta = Math.random() * 2 - 1;
      const u = Math.random();
      const radius = TREE_CONFIG.CHAOS_RADIUS * Math.pow(u, 1/3);
      const sinTheta = Math.sqrt(1 - cosTheta * cosTheta);

      cPos[i * 3] = radius * sinTheta * Math.cos(phi);
      cPos[i * 3 + 1] = radius * cosTheta;
      cPos[i * 3 + 2] = radius * sinTheta * Math.sin(phi);

      noise[i * 3] = (Math.random() - 0.5) * 2;
      noise[i * 3 + 1] = (Math.random() - 0.5) * 2;
      noise[i * 3 + 2] = (Math.random() - 0.5) * 2;

      const normalizedX = (point[0] - minX) / width;
      const color = getGradientColor(THREE.MathUtils.clamp(normalizedX, 0, 1));
      bCols[i * 3] = color.r;
      bCols[i * 3 + 1] = color.g;
      bCols[i * 3 + 2] = color.b;
    }

    return { positions: pos, chaosPositions: cPos, baseColors: bCols, noiseOffsets: noise };
  }, []);

  useFrame((stateObj, delta) => {
    const target = state === TreeState.FORMED ? 1 : 0;
    progressRef.current = THREE.MathUtils.lerp(progressRef.current, target, delta * 2.5);

    const time = stateObj.clock.getElapsedTime();
    const attrPos = pointsRef.current.geometry.attributes.position;
    const attrCol = pointsRef.current.geometry.attributes.color;
    
    // Scale glow intensity with formation progress
    // When progress is 1, multiplier is 2.5, making colors > 1.0 to trigger Bloom
    const glowMultiplier = 1.0 + progressRef.current * 2.0;

    for (let i = 0; i < TEXT_CONFIG.PARTICLE_COUNT; i++) {
      const idx = i * 3;
      
      // Core interpolation
      const basePosX = THREE.MathUtils.lerp(chaosPositions[idx], positions[idx], progressRef.current);
      const basePosY = THREE.MathUtils.lerp(chaosPositions[idx + 1], positions[idx + 1], progressRef.current);
      const basePosZ = THREE.MathUtils.lerp(chaosPositions[idx + 2], positions[idx + 2], progressRef.current);
      
      const turbulenceIntensity = (1 - progressRef.current) * 0.5;
      const noiseX = Math.sin(time * 0.5 + noiseOffsets[idx] * 10) * turbulenceIntensity;
      const noiseY = Math.cos(time * 0.4 + noiseOffsets[idx + 1] * 10) * turbulenceIntensity;
      const noiseZ = Math.sin(time * 0.6 + noiseOffsets[idx + 2] * 10) * turbulenceIntensity;

      attrPos.array[idx] = basePosX + noiseX;
      attrPos.array[idx + 1] = basePosY + noiseY;
      attrPos.array[idx + 2] = basePosZ + noiseZ;
      
      // Update dynamic emissive colors
      attrCol.array[idx] = baseColors[idx] * glowMultiplier;
      attrCol.array[idx + 1] = baseColors[idx + 1] * glowMultiplier;
      attrCol.array[idx + 2] = baseColors[idx + 2] * glowMultiplier;

      // Gentle floating when formed
      if (progressRef.current > 0.98) {
        attrPos.array[idx + 1] += Math.sin(time * 1.5 + i * 0.05) * 0.003;
        attrPos.array[idx] += Math.cos(time * 1.2 + i * 0.05) * 0.002;
      }
    }
    
    attrPos.needsUpdate = true;
    attrCol.needsUpdate = true;

    // Maintain high opacity and slight size breathing for the glow
    const material = pointsRef.current.material as THREE.PointsMaterial;
    material.opacity = 0.7 + progressRef.current * 0.3;
    material.size = 0.14 + Math.sin(time * 2) * 0.01 * progressRef.current;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={TEXT_CONFIG.PARTICLE_COUNT}
          array={chaosPositions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={TEXT_CONFIG.PARTICLE_COUNT}
          array={new Float32Array(baseColors)}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.14}
        vertexColors
        transparent
        opacity={0.7}
        blending={THREE.AdditiveBlending}
        sizeAttenuation
      />
    </points>
  );
};

export default TextParticles;
