
export enum TreeState {
  CHAOS = 'CHAOS',
  FORMED = 'FORMED'
}

export interface OrnamentData {
  chaosPos: [number, number, number];
  targetPos: [number, number, number];
  type: 'ball' | 'box' | 'light';
  color: string;
  scale: number;
  weight: number;
}
